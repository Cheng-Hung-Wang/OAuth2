from django.apps import AppConfig


class Oauth2Config(AppConfig):
    name = 'oauth2'
