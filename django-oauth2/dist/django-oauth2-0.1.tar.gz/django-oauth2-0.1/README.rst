=====
oauth2
=====

oauth2 client is a simple Django app, it is user oauth2 to get user profile.


Quick start
-----------

1. Add "django-oauth2" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'django-oauth2',
    ]

2. Exampel on accounts app::

3. Run `python manage.py runserver` to runserver.

